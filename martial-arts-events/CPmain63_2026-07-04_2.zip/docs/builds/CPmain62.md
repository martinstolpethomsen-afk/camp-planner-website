# Change Report — CPmain61 → CPmain62

**Build date:** 2026-07-04
**Output size:** 668,087 bytes

## What changed — Camp Overview hero: light + rounded

Restyled the Camp Overview hero from a dark `#111` banner to a white rounded card:
- Background dark → white (`#fff`), subtle border (`#E9E7E0`), soft shadow.
- Corners rounded to 16px (readiness tile 12px); 20px gap below the hero.
- Text recolored for the light background (dark camp name, muted-gray labels, `#777` dates/location).
- Readiness % color re-tuned for contrast on white (green/amber/red).
- Settings button → light bordered style.
- Kept the red→gold accent bar (clipped to the rounded top) and the red logo tile.

## What was NOT changed

Only the Camp Overview hero's presentation. Dashboard hero and everything else untouched. No logic, auth, DB, routing, or icon changes.

## Suggested commit message

```
style: Camp Overview hero to light rounded card (16px) (CPmain62)
```
