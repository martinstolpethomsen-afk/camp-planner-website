# Camp-Planner — Product Decisions

A record of important product and architecture decisions so the reasoning doesn't get lost. Newest decisions can be added at the top. Each entry: the decision, a short why, and its status.

_Recorded: 2026-07-04_

---

## Data & camp lifecycle

**1. Do not hard-delete camps in v0.1**
- Decision: camps are never permanently deleted in this version.
- Why: protects against accidental loss of camp data while the product is young; keeps recovery simple.
- Status: Active.

**2. Deleted camps are soft-hidden and restorable**
- Decision: "deleting" a camp soft-hides it; it can be restored.
- Why: reversible by design; pairs with decision #1.
- Status: Active (implemented).

**3. Admins can view hidden / deleted camps**
- Decision: an admin surface can see soft-hidden/deleted camps.
- Why: recovery and oversight; nothing truly disappears.
- Status: Active (admin surface being finished — see FEATURE_BACKLOG P1).

---

## Navigation & module placement

**4. Finance Actuals belong under Finance**
- Decision: actual/realized economy lives under Finance › Actuals, not as a separate workflow item or under Reports.
- Why: one home for money; avoids duplicate/competing routes.
- Status: Active (old `realized` route redirects to `fin-actuals`).

**5. "Outcome" is renamed to "Reports"**
- Decision: the user-facing label is **Reports**. The internal route/key may stay `outcome` for compatibility.
- Why: "Reports" is what users expect and understand.
- Status: Active (implemented).

---

## Platform identity & domains

**6. Target camp-planner.online as the broader platform identity (long term)**
- Decision: position the product around **camp-planner.online** as the platform going forward.
- Why: broader, sport-agnostic identity beyond a single-market entry point.
- Status: Directional (guides UI alignment work — see FEATURE_BACKLOG P1/P3).

**7. .dk may remain a Danish entry point, but must not be hardcoded as the only future domain**
- Decision: keep `.dk` as a Danish entry point; do not bake it in as the sole/permanent domain.
- Why: keeps the door open for international expansion without rework.
- Status: Active constraint.

---

## Architecture & deployment

**8. Keep the current architecture: source/module files + Python build script**
- Decision: retain the existing source/module structure and the Python build script that assembles them.
- Why: proven workflow; no reason to re-platform now.
- Status: Active.

**9. Final deployment remains one built index.html (for now)**
- Decision: ship a single built `index.html` (GitHub → Vercel).
- Why: simple, fast to deploy; matches current scale.
- Status: Active ("for now" — revisit if scale/tooling needs change).
