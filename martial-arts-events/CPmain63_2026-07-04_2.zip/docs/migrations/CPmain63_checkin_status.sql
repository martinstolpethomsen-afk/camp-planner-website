-- CPmain63 — Check-in module v0.1
-- Adds arrival status to attendees so check-ins persist across refresh/camp day.
-- Run once in the Supabase SQL editor (safe to re-run; idempotent).

alter table attendees
  add column if not exists checkin_status text default 'not_arrived';

-- Values used by the app: 'not_arrived' (default), 'checked_in', 'no_show'.
