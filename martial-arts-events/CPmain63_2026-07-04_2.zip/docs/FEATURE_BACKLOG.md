# Camp-Planner — Feature Backlog

Track feature wishes, product ideas, bugs, and priorities. This is a living list — priorities are a starting proposal, reorder freely as the product direction sharpens.

**Priority key**
- **P0** — Must fix / blockers (app-breaking, ships-first)
- **P1** — Core product (the experience running camps depends on)
- **P2** — SaaS scale (multi-org, performance, monetization)
- **P3** — Product expansion (new surfaces, integrations, reach)
- **Parked** — Good ideas, not now
- **Done** — Shipped

_Item status tags: (partial) = started, needs finishing._

---

## P0 — Must fix / blockers

_None open._ Recent blockers were resolved on 2026-07-04 (unterminated `<script>` tag; Dashboard "stuck at Loading camps" freeze). Keep this section empty unless something breaks the app.

- Loading / performance guardrails — (partial) query timeout + non-blocking counts are in; keep watching for slow paths and add guardrails where a screen can hang.

---

## P1 — Core product

- **Check-in module** — v0.1 shipped 2026-07-04 (Action › Check-in): manual check-in, search by name/email/club, Not-arrived/Checked-in/No-show status, live arrival count, payment/dietary/accommodation warnings, badge printing. Requires the `attendees.checkin_status` column.
  - _Remaining (v0.2):_ dedicated check-in-team role (front-desk access without full admin); arrival timestamps; bulk badge printing.
- Admin view of hidden / deleted camps — (partial) soft-hide + restore exist; finish the admin surface to browse hidden/deleted camps.
- Volunteer module — expand beyond the current volunteers tab (roles, shifts, sign-up).
- Event type icon system — (partial) inline SVG icon library is now in place; extend/curate the per-sport / per-event-type icon mapping.
- Reports exports — feedback, NPS, camp report, participant report, session report, post-camp summary, and export outputs.
- UI alignment with **camp-planner.online** — bring the app's look in line with the broader platform identity (ongoing; hero restyle 2026-07-04 was a first step).

---

## P2 — SaaS scale

- Scale readiness for ~2000 organizations — make the data model and queries hold up at that volume.
- Server-side counts — move KPI/count aggregation server-side (Supabase) instead of client fan-out.
- Pagination in Platform Admin — paginate org/camp lists so admin screens stay fast.
- Search / filter organizations — find orgs quickly in Platform Admin.
- Payment integration — Stripe / PayPal / MobilePay (participant fees, org billing). MobilePay covers the Danish market.

---

## P3 — Product expansion

- Broader platform identity around **camp-planner.online** (see DECISIONS.md) — positioning, domains, marketing surfaces.
- (Move items up from Parked here as they earn a place on the roadmap.)

---

## Parked ideas

- Hard-delete of camps — intentionally **not** in v0.1 (see DECISIONS.md). Revisit only with a strong reason.
- Additional payment providers beyond Stripe / PayPal / MobilePay.

---

## Done

- **Build marker verification** — sequential build naming (CPmainNN) + `node --check` syntax verification per build. ✅
- **Soft-hide / restore camps** — camps are soft-hidden and restorable, not hard-deleted. ✅
- **Organization branded login page** — org-branded login. ✅
- **Customer login URL via `#org/{slug}`** — org-scoped login entry. ✅
- **Finance: Budget / Actuals / Payments** — Finance module with Summary / Budget / Actuals / Payments sub-nav. ✅
- **Reports instead of Outcome** — user-facing label is "Reports" (internal key `outcome` retained). ✅
- **Finance Actuals only under Finance** — old `realized` route redirects to `fin-actuals`; not exposed elsewhere. ✅
- **Dashboard cleanup** — removed duplicate Event Overview widget; hero simplified. ✅
- **Sidebar icons** — sidebar uses inline SVG; whole app converted to inline SVG sprite (no CDN webfont dependency) on 2026-07-04. ✅
