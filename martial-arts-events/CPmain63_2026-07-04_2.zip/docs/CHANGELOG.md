# Camp-Planner — Changelog

What changed after each Claude iteration. Newest first.

Format:
```
YYYY-MM-DD — Short title
Changed:
Fixed:
Known limitations:
Tested:
```

---

## 2026-07-04 — CPmain63 — Check-in module v0.1 (Action tab)
Changed:
- New Check-in tab under Action: manual check-in (Checked in / No-show / Undo), search by name/email/club, live arrival counters, payment/dietary/accommodation warning chips, and per-attendee badge printing. Access gated to camp admins; badges printable by all.
Fixed:
- n/a (new feature).
Known limitations:
- Requires a one-time `attendees.checkin_status` column (see docs/migrations/CPmain63_checkin_status.sql). Dedicated check-in-team role and arrival timestamps are v0.2.
Tested:
- Tab renders and routes under Action; status persists and counts update live; search filters; badge prints; other Action tabs unaffected; `node --check` ✓.

## 2026-07-04 — CPmain62 — Camp Overview hero: light + rounded
Changed:
- Camp Overview hero restyled from dark `#111` banner to a white rounded card (16px), subtle border + soft shadow, with light-appropriate text colors and a light Settings button. Kept the red→gold accent bar and red logo tile.
Fixed:
- Readiness % color re-tuned for contrast on the light background (green/amber/red).
Known limitations:
- Only the Camp Overview hero was lightened; the Dashboard hero is still dark.
Tested:
- Hero renders as a light card; text readable (no white-on-white); accent bar and Settings link intact; embedded JS passes `node --check`.

## 2026-07-04 — CPmain61 — App-wide icon conversion to inline SVG
Changed:
- Converted all 423 `<i class="ti …">` webfont icons to inline SVG (`<svg><use href="#ti-…"/>`); added 87 icon symbols to the inline sprite (126 total) from Tabler 2.47.0 geometry; added a `.ti-svg` sizing rule.
Fixed:
- Icons no longer depend on the Tabler CDN webfont, so they can no longer blank out when the CDN fails.
Known limitations:
- No font fallback by design: a newly hand-added `<i class="ti …">` won't render unless its symbol is in the sprite.
Tested:
- 0 remaining webfont icons; all 126 icon references resolve to a symbol; JS passes `node --check`.

## 2026-07-04 — CPmain60 — Camp Overview Quick Launch + KPI icons
Changed:
- Converted the Camp Overview Quick Launch and KPI icons to inline SVG; added the `ti-award` symbol.
Fixed:
- Quick Launch black-box / missing icons on the Camp Overview.
Known limitations:
- Other pages still used the CDN webfont at this point (resolved in CPmain61).
Tested:
- Quick Launch and KPI icons render; JS passes `node --check`.

## 2026-07-04 — CPmain59 — Dashboard "stuck at Loading camps" fix
Changed:
- Removed an undefined `${campActions}` reference from the Dashboard camp-card template.
Fixed:
- Dashboard froze on the "Loading camps…" spinner whenever an org had at least one camp (ReferenceError while building the HTML). Camp-management actions remain on the Camps page as before.
Known limitations:
- None for this fix.
Tested:
- Dashboard loads camp cards for orgs with camps; empty orgs show the empty state; static sweep found no other out-of-scope references; JS passes `node --check`.

## 2026-07-04 — CPmain58 — Restore corrupted closing `</script>` tag
Changed:
- Removed orphaned `.dash-hero-widget` CSS + a stale media-query rule left over from the earlier Dashboard hero cleanup.
Fixed:
- The main `<script>` block was unterminated (closing tag corrupted to `t>`), which prevented the entire app from parsing (blank page). Restored `</script>`.
Known limitations:
- Superseded same day by CPmain59+ (kept here for history).
Tested:
- Script tags balanced; embedded JS passes `node --check`.

## 2026-07-03 — CPmain57 — Dashboard load fix (Supabase Promise.race)
Changed:
- Materialized the camps query as a real Promise (`.then(r => r)`) before `Promise.race`.
Fixed:
- Dashboard showed zero camps on org select because the raw query builder passed to `Promise.race` never executed and fell through to the 10s timeout.
Known limitations:
- See later entries for the `<script>` and dashboard-freeze issues discovered afterward.
Tested:
- Camps load per org; non-blocking counts fill in after cards; `node --check` ✓.
