# Camp-Planner — Scale Readiness v0.1

**Goal:** hold up cleanly at ~2,000 organizations (and their camps, attendees, sessions) without slow loads or runaway data transfer.
**Date:** 2026-07-04 · Assessed against CPmain63.

This is an audit + roadmap, not a code change. It names the specific hot paths and the order I'd fix them. Nothing here touches Planning, Finance, auth, 2FA, or table names.

---

## What's already solid

- **Load guardrails exist:** the dashboard camps query has a 10s timeout guard, and counts are **non-blocking** — the page renders first, counts patch in after. Good instinct; keep it.
- Queries are already scoped by org/camp (`.eq`, `.in`), so the shape is right — the issue is *how much* they pull, not correctness.

## Findings (grounded in the code)

**1. Client-side counting instead of asking the DB for a count.**
- Overview KPIs (per camp) fetch every instructor/attendee/session/area **row** just to count them: `sb.from('attendees').select('id').eq('camp_id', camp.id)` then `.length`. A 300-person camp transfers 300 rows to show the number "300."
- Dashboard KPIs do the same across all camps in an org: `select('camp_id').in('camp_id', campIds)` for attendees + instructors + sessions, tallied in the browser. An org with many camps pulls thousands of rows to show three numbers.
- Only 2 queries in the whole app use server-side `count:'exact'`.

**2. No pagination anywhere.**
- `.range(` and `.limit(` appear **zero** times. Every list — attendees, camps, volunteers, and the Platform Admin org list — fetches *all* rows.

**3. Platform Admin loads everything, every time.**
- On load it pulls **all** organizations (`select('*')`), **all** profiles, **all** members, and **all** camps in parallel, with no pagination and no server-side search. At 2,000 orgs this is the single heaviest path in the app.

**4. Broad `select('*')` on tables that grow.**
- `organizations`, `attendees`, `camps`, `volunteers` are read with `select('*')` — all columns, all rows — even where only a few fields are shown.

**5. Indexes (can't verify from here — flagging).**
- Everything filters on `camp_id`, `organization_id`, or `id`. At scale those columns need indexes or the queries above get slow regardless of how much we trim.

---

## Prioritized roadmap

### Tier 1 — App-code only, no DB change, safe, high ROI (recommended v0.2 build)

- **1a. Server-side counts for Overview KPIs.** Replace the 4 `select('id') → .length` counts with `select('*', { count: 'exact', head: true })`. Returns just the number, transfers zero rows. Small, contained, big per-camp win.
- **1b. Platform Admin pagination + server-side search.** Add `.range(from, to)` paging and an `ilike` name search with `count:'exact'` for the total. Turns a full-table pull into one page at a time.
- **1c. Narrow the list `select('*')`** to the columns actually rendered (attendees list, camps list, org list).

### Tier 2 — Needs your DB go-ahead (schema/index, delivered as migrations)

- **2a. FK indexes** (below). Biggest bang-for-buck; makes every scoped query fast.
- **2b. One RPC/view for per-camp counts.** A single `camp_counts` view (or RPC) returning `camp_id, attendees, instructors, sessions` in one round trip replaces the dashboard fan-out entirely.
- **2c. Org search index** — a trigram index on `organizations.name` if the admin search needs to stay instant at 2,000 rows.

### Tier 3 — Only if 2,000+ demands it

- Materialized views / cached counters, edge caching. Don't build until numbers say so — avoid premature complexity.

---

## Suggested index migration (Tier 2a)

Review against your actual schema before running; these are the columns the app filters on.

```sql
create index if not exists idx_attendees_camp_id    on attendees(camp_id);
create index if not exists idx_sessions_camp_id     on sessions(camp_id);
create index if not exists idx_instructors_camp_id  on instructors(camp_id);
create index if not exists idx_areas_camp_id        on areas(camp_id);
create index if not exists idx_volunteers_camp_id   on volunteers(camp_id);
create index if not exists idx_camps_org_id         on camps(organization_id);
create index if not exists idx_org_members_org_id   on organization_members(organization_id);
create index if not exists idx_org_members_user_id  on organization_members(user_id);
```

---

## Recommended sequence

1. **v0.2 build (Tier 1)** — server-side counts + Platform Admin pagination/search + narrowed selects. App-code only, low risk, immediately noticeable.
2. **Add indexes (Tier 2a)** — one migration; pairs with everything above.
3. **camp_counts view (Tier 2b)** — retire the dashboard fan-out.
4. Re-measure. Only reach for Tier 3 if real numbers justify it.

## What NOT to change

Query correctness, org/camp scoping, auth/2FA, table names, routing, Planning/Finance logic. Scale work is about *how much* we fetch and *what's indexed* — not what the queries mean.
