# Camp-Planner

**Built for martial arts. Ready for every sport.**
_Plan · Organize · Inspire_

Camp-Planner is a web app for running martial-arts and sports camps end to end — from first plan to camp day to the post-camp wrap-up. It brings scheduling, participants, instructors, areas, finance, and live display screens into one place so organizers spend less time wrangling logistics and more time on the camp itself.

---

## What it does

Camp-Planner is organized as a simple workflow, phase by phase:

- **Overview** — camp readiness at a glance: status, key numbers, and the next best action.
- **Planning** — build the schedule, assign instructors, volunteers, and areas.
- **Setup** — camp settings and budget setup.
- **Action** — run the camp: sign-ups, attendees, check-in, shifts, info page.
- **Reports** — feedback, NPS, camp/participant/session reports, exports, post-camp summary.
- **Finance** — Summary, Budget, Actuals, and Payments in one place.
- **Live screen** — a venue display board for the camp day.

Camps are multi-tenant per organization, with organization-branded login. Camps are never hard-deleted — they're soft-hidden and restorable.

## Tech at a glance

- **Frontend:** a single compiled `index.html` (assembled from source/module files by a Python build script).
- **Icons:** inline SVG sprite (Tabler geometry), so icons render without any CDN dependency.
- **Backend:** Supabase.
- **Deploy:** GitHub → Vercel, serving one built `index.html`.

## Project structure

```
index.html            The built application (what ships)
README.md             This overview
docs/
  FEATURE_BACKLOG.md  Feature wishes, ideas, bugs — prioritized (P0–P3)
  DECISIONS.md        Product & architecture decisions, with the "why"
  CHANGELOG.md        Running history of what changed each build
  builds/             Full per-build change reports (CPmainNN.md)
```

## How changes are tracked

- **[docs/CHANGELOG.md](docs/CHANGELOG.md)** — the running summary of every build (newest first).
- **docs/builds/CPmainNN.md** — the detailed change report for each individual build (what changed, what was intentionally left untouched, how it was verified, test checklist).
- **[docs/FEATURE_BACKLOG.md](docs/FEATURE_BACKLOG.md)** — where the roadmap lives.
- **[docs/DECISIONS.md](docs/DECISIONS.md)** — why things are the way they are.

Builds are named sequentially (CPmainNN) and syntax-checked with `node --check` before release.
